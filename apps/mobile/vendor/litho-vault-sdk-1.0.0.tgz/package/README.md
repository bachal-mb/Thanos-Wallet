# @litho-vault/sdk 1.0.0

TypeScript SDK for Litho Vault (LEP100-15) multisignature accounts on Lithosphere.

Built from https://github.com/imasssad/litho-vault (packages/sdk). Documentation: docs/ENGINEERING.md in that repository.
